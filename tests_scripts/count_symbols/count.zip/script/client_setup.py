from utils import test

def handle(data):
    return len(data)
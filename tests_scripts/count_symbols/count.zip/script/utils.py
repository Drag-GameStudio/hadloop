def test():
    print("This is a test function in utils.py")
    return "Test completed successfully"